package com.example.venkatesh.inclass06;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.widget.ImageView;
import android.widget.LinearLayout;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.MissingFormatArgumentException;

/**
 * Created by Venkatesh on 9/26/2016.
 */
public class GetPhotos extends AsyncTask<String,Void,Bitmapid> {

    int id;

    putdata tempput;


    public GetPhotos(putdata n)
    {
        this.tempput=n;
    }

    interface putdata
    {
        void putdata(Bitmapid bitmapid);

    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();

    }

    @Override
    protected void onPostExecute(Bitmapid bitmapid) {
        super.onPostExecute(bitmapid);


        tempput.putdata(bitmapid);

    }

    @Override
    protected Bitmapid doInBackground(String... params) {

        try {

            URL url = new URL(params[0]);
           id=Integer.parseInt(params[1]);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            Bitmap image = BitmapFactory.decodeStream(con.getInputStream());
            Bitmapid tempbitmapid=new Bitmapid();
            tempbitmapid.setId(id);
            tempbitmapid.setBitmap(image);
            return tempbitmapid;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;


    }
}
