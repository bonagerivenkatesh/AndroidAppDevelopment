package com.example.venkatesh.inclass06;

import android.graphics.Bitmap;

/**
 * Created by Venkatesh on 9/27/2016.
 */
public class Bitmapid {

    Bitmap bitmap;
    int id;

    public Bitmap getBitmap() {
        return bitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
