package com.example.venkatesh.inclass06;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by Venkatesh on 9/27/2016.
 */
public class GetPhotoDescription extends AsyncTask<String, Void, Bitmap>{

    putdata tempput;


    public GetPhotoDescription (putdata n)
    {
        this.tempput=n;
    }

    interface putdata
    {
        void putdata(Bitmap bitmap);

    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {
        super.onPostExecute(bitmap);

        tempput.putdata(bitmap);

    }

    @Override
    protected Bitmap doInBackground(String... params) {

        if(params[0]!=null) {

            try {
                URL url = new URL(params[0]);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("GET");
                Bitmap image = BitmapFactory.decodeStream(con.getInputStream());
                return image;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return null;
    }
}
