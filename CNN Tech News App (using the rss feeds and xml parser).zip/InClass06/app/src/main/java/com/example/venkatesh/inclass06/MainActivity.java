package com.example.venkatesh.inclass06;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Movie;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MainActivity extends AppCompatActivity implements GetNews.putdata, GetPhotos.putdata, View.OnClickListener {

    ArrayList<News> newslist = new ArrayList<News>();
   public static ProgressDialog progress;

    @Override
    public void putdata(Bitmapid bitmapid) {

        LinearLayout mainlayout = (LinearLayout) findViewById(R.id.mainlinearlayout);

        int id=bitmapid.getId();
        Bitmap bitmap=bitmapid.getBitmap();

        ImageView ivthumbnail = new ImageView(this);
        LinearLayout topiclayout = new LinearLayout(this);
            TextView text= new TextView(this);
            topiclayout.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            topiclayout.setLayoutParams(params);

            text.setText(newslist.get(id).getTitle());
            text.setId(id+100);
            text.setOnClickListener(this);
            text.setTag(id);
            text.setPadding(25,0,0,0);

            ivthumbnail.setId(id);
            ivthumbnail.setImageBitmap(bitmap);
            ivthumbnail.setTag(id);
            ivthumbnail.setOnClickListener(this);

            topiclayout.setId(id+200);
            topiclayout.addView(ivthumbnail);

            topiclayout.addView(text);

            mainlayout.addView(topiclayout);

    }

    @Override
    public void putdata(ArrayList<News> newslist1) {

        newslist=newslist1;

        Collections.sort(newslist,
                new Comparator<News>() {
                    public int compare(News n1, News n2) {

                        return n1.getPubdate().compareTo(n2.getPubdate());
                        //return -1*n1.getPubdate().compareTo(n2.getPubdate());-----for descending pubdate
                    }

                });

        for(int i=0;i<newslist.size();i++)
        {
            new GetPhotos(this).execute(newslist.get(i).getImage2(),i+"");
        }

    }

    public void onClick(View v) {

        Intent i = new Intent(getApplicationContext(),NewsDetailsActivity.class);
        i.putExtra("ID",v.getTag().toString());
        i.putExtra("array",newslist);

        startActivity(i);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        progress=new ProgressDialog(this);

        new GetNews(this).execute("http://rss.cnn.com/rss/cnn_tech.rss");


    }
}
