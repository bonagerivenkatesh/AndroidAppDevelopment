package com.example.venkatesh.inclass06;

import android.util.Log;
import android.widget.Switch;

import org.xml.sax.helpers.DefaultHandler;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;

/**
 * Created by Venkatesh on 9/26/2016.
 */
public class NewsParser  {

    static public class newsparser {

        static ArrayList<News> parsePerson(InputStream in) {

            try {



                XmlPullParser parser = XmlPullParserFactory.newInstance().newPullParser();

                parser.setInput(in,"UTF-8");

                ArrayList<News> newslist = new ArrayList<News>();

                News tempnews=tempnews= new News();
                tempnews=null;

                int event=parser.getEventType();



                parser.next();
                int tempflag=0;




                while (event!=XmlPullParser.END_DOCUMENT && tempflag==0)
                {
                    switch(event)
                    {
                        case XmlPullParser.START_TAG:   if(parser.getName().equals("item"))
                        {
                            tempflag=1;
                        }
                            else
                        {
                            event=parser.next();
                        }

                            break;

                        default: event=parser.next();
                            break;
                    }


                }

                while (event!=XmlPullParser.END_DOCUMENT)
                {
                    switch(event)
                    {
                        case XmlPullParser.START_TAG:
                            if(parser.getName().equals("item"))
                                tempnews= new News();
                            if(parser.getName().equals("title"))
                            tempnews.setTitle(parser.nextText().trim());
                            else if(parser.getName().equals("description"))
                                tempnews.setDescription(parser.nextText().trim());
                            else if(parser.getName().equals("pubDate"))
                                tempnews.setPubdate(parser.nextText().trim());
                            else if(parser.getName().equals("link"))
                                tempnews.setLink(parser.nextText().trim());
                            else if( parser.getName().equals("media:content"))
                            {
                                if((parser.getAttributeValue(null,"width")).equals("1100"))
                                {
                                    tempnews.setImage1(parser.getAttributeValue(null,"url"));
                                }
                                else if((parser.getAttributeValue(null,"width")).equals("300"))
                                {
                                    tempnews.setImage2(parser.getAttributeValue(null,"url"));
                                }
                                if(tempnews.getImage1()== null)
                                    if((parser.getAttributeValue(null,"width")).equals("576")) {
                                        tempnews.setImage1(parser.getAttributeValue(null,"url"));
                                    }
                            }

                            break;

                        case XmlPullParser.END_TAG: if (parser.getName().equals("item"))
                        {
                           newslist.add(tempnews);
                            tempnews=null;
                        }
                            break;

                        default: break;
                    }

                    event=parser.next();
                }

                    return newslist;

            } catch (Exception e) {
                Log.d("debug", e.getMessage());
            }

            return null;
        }
    }


}
