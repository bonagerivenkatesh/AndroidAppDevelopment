package com.example.venkatesh.inclass06;

import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class NewsDetailsActivity extends AppCompatActivity implements GetPhotoDescription.putdata {

    @Override
    public void putdata(Bitmap bitmap) {
        ImageView ivimage = (ImageView) findViewById(R.id.detailsivimage);

        ivimage.setImageBitmap(bitmap);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_details);

        int id= Integer.parseInt(getIntent().getExtras().getString("ID"));
        ArrayList<News> newslist = (ArrayList<News>) getIntent().getSerializableExtra("array");

        TextView tvtitle = (TextView) findViewById(R.id.detailstvtitle);
        TextView tvdate = (TextView) findViewById(R.id.detailstvdate);

        TextView tvdescription = (TextView) findViewById(R.id.detailstvdescriptiondis);

        Date date=newslist.get(id).getPubdate();

        DateFormat tempformat =  new SimpleDateFormat("MM/dd/yyyy hh:mm a", Locale.ENGLISH);

        tvtitle.setText(newslist.get(id).getTitle());

        tvdate.setText(tempformat.format(date));

        tvdescription.setText(newslist.get(id).getDescription());

        new GetPhotoDescription(this).execute(newslist.get(id).getImage1());

    }
}
