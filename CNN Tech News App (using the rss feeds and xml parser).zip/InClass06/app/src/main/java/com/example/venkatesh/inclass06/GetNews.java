package com.example.venkatesh.inclass06;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.util.Log;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by Venkatesh on 9/26/2016.
 */
public class GetNews extends AsyncTask<String, Void, ArrayList<News>> {


    putdata tempput;


    public GetNews(putdata n)
    {
        this.tempput=n;
    }

    interface putdata
    {
        void putdata(ArrayList<News>  newslist);

    }


    @Override
    protected void onPostExecute(ArrayList<News> arrayList) {
        super.onPostExecute(arrayList);

        Log.d("debug",arrayList.toString());

        MainActivity.progress.dismiss();
        tempput.putdata(arrayList);

    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        MainActivity.progress.setCancelable(false);
        MainActivity.progress.setMessage("Loading News...");
        MainActivity.progress.show();
    }

    @Override
    protected ArrayList<News> doInBackground(String... params) {
        try {
            URL url = new URL(params[0]);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.connect();

            int statuscode = con.getResponseCode();

            if(statuscode == HttpURLConnection.HTTP_OK)
            {
                InputStream in = con.getInputStream();

                return NewsParser.newsparser.parsePerson(in);

            }

        }
        catch (Exception e)
        {
            Log.d("demo","Something weng wrong");
        }


        return null;

    }
}
