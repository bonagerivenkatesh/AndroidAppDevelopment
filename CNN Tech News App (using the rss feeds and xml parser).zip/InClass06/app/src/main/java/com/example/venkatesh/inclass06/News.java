package com.example.venkatesh.inclass06;

import android.graphics.Bitmap;
import android.util.Log;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Created by Venkatesh on 9/26/2016.
 */
public class News implements Serializable{

    String title, description,link,image1,image2;
    Bitmap large, small;
    Date pubdate;




    public void setLarge(Bitmap large) {
        this.large = large;
    }

    public Bitmap getSmall() {
        return small;
    }

    public void setSmall(Bitmap small) {
        this.small = small;
    }

    @Override
    public String toString() {
        return "News{" +
                "title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", link='" + link + '\'' +
                ", image1='" + image1 + '\'' +
                ", image2='" + image2 + '\'' +
                ", pubdate=" + pubdate +
                '}';
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getImage1() {
        return image1;
    }

    public void setImage1(String image1) {
        this.image1 = image1;
    }

    public String getImage2() {
        return image2;
    }

    public void setImage2(String image2) {
        this.image2 = image2;
    }

    public Date getPubdate() {

        return pubdate;
    }

    public void setPubdate(String pubdate) {

        try {
            DateFormat format = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", Locale.ENGLISH);
            Date date = format.parse(pubdate);
            this.pubdate = date;
        }
        catch (Exception e)
        {
            Log.d("debug",e.getMessage());
        }

    }
}
